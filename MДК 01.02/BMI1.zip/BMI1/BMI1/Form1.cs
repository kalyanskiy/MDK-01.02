﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BMI1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void HeightBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void WeightBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double heightSm = Convert.ToInt32(HeightBox.Text);
            double heightM = heightSm / 100;

            double weight = Convert.ToInt32(WeightBox.Text);
            double BMIkoef = weight / (heightM * heightM);
            BMIkoef = Math.Round(BMIkoef, 1);
            StatusBox.Text = Convert.ToString(BMIkoef); StatusBox.Visible = true;
            WeightBar.Value = Convert.ToInt32(BMIkoef);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
