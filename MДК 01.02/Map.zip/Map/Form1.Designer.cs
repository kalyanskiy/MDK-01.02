﻿namespace Map
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.labeltop = new System.Windows.Forms.Label();
            this.labelofdrink = new System.Windows.Forms.Label();
            this.labelofenergy = new System.Windows.Forms.Label();
            this.labelofinf = new System.Windows.Forms.Label();
            this.labelofmedicine = new System.Windows.Forms.Label();
            this.labeloftoilet = new System.Windows.Forms.Label();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxOfToilet = new System.Windows.Forms.PictureBox();
            this.pictureBoxOfMedical = new System.Windows.Forms.PictureBox();
            this.pictureBoxOfInformation = new System.Windows.Forms.PictureBox();
            this.pictureBoxOfEnergy = new System.Windows.Forms.PictureBox();
            this.pictureBoxOfDrink = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOfToilet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOfMedical)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOfInformation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOfEnergy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOfDrink)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Controls.Add(this.labeloftoilet);
            this.panel1.Controls.Add(this.labelofmedicine);
            this.panel1.Controls.Add(this.labelofinf);
            this.panel1.Controls.Add(this.labelofenergy);
            this.panel1.Controls.Add(this.pictureBoxOfToilet);
            this.panel1.Controls.Add(this.pictureBoxOfMedical);
            this.panel1.Controls.Add(this.pictureBoxOfInformation);
            this.panel1.Controls.Add(this.pictureBoxOfEnergy);
            this.panel1.Controls.Add(this.pictureBoxOfDrink);
            this.panel1.Controls.Add(this.labelofdrink);
            this.panel1.Controls.Add(this.labeltop);
            this.panel1.Location = new System.Drawing.Point(411, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(387, 446);
            this.panel1.TabIndex = 3;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // labeltop
            // 
            this.labeltop.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labeltop.Location = new System.Drawing.Point(-2, 0);
            this.labeltop.Name = "labeltop";
            this.labeltop.Size = new System.Drawing.Size(389, 74);
            this.labeltop.TabIndex = 0;
            this.labeltop.Text = "label1";
            this.labeltop.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labeltop.Click += new System.EventHandler(this.label1_Click);
            // 
            // labelofdrink
            // 
            this.labelofdrink.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelofdrink.Location = new System.Drawing.Point(110, 73);
            this.labelofdrink.Name = "labelofdrink";
            this.labelofdrink.Size = new System.Drawing.Size(263, 65);
            this.labelofdrink.TabIndex = 1;
            this.labelofdrink.Text = "label2";
            // 
            // labelofenergy
            // 
            this.labelofenergy.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelofenergy.Location = new System.Drawing.Point(110, 144);
            this.labelofenergy.Name = "labelofenergy";
            this.labelofenergy.Size = new System.Drawing.Size(257, 65);
            this.labelofenergy.TabIndex = 7;
            this.labelofenergy.Text = "label3";
            // 
            // labelofinf
            // 
            this.labelofinf.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelofinf.Location = new System.Drawing.Point(110, 215);
            this.labelofinf.Name = "labelofinf";
            this.labelofinf.Size = new System.Drawing.Size(263, 65);
            this.labelofinf.TabIndex = 8;
            this.labelofinf.Text = "label4";
            // 
            // labelofmedicine
            // 
            this.labelofmedicine.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelofmedicine.Location = new System.Drawing.Point(110, 286);
            this.labelofmedicine.Name = "labelofmedicine";
            this.labelofmedicine.Size = new System.Drawing.Size(257, 65);
            this.labelofmedicine.TabIndex = 9;
            this.labelofmedicine.Text = "label5";
            // 
            // labeloftoilet
            // 
            this.labeloftoilet.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labeloftoilet.Location = new System.Drawing.Point(110, 357);
            this.labeloftoilet.Name = "labeloftoilet";
            this.labeloftoilet.Size = new System.Drawing.Size(257, 65);
            this.labeloftoilet.TabIndex = 10;
            this.labeloftoilet.Text = "label6";
            this.labeloftoilet.Click += new System.EventHandler(this.label6_Click);
            // 
            // pictureBox16
            // 
            this.pictureBox16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox16.Image = global::Map.Properties.Resources.map_icon_start1;
            this.pictureBox16.Location = new System.Drawing.Point(156, 28);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(56, 46);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox16.TabIndex = 13;
            this.pictureBox16.TabStop = false;
            this.pictureBox16.Click += new System.EventHandler(this.pictureBox16_Click);
            // 
            // pictureBox15
            // 
            this.pictureBox15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox15.Image = global::Map.Properties.Resources._8;
            this.pictureBox15.Location = new System.Drawing.Point(43, 145);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(42, 45);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox15.TabIndex = 12;
            this.pictureBox15.TabStop = false;
            this.pictureBox15.Click += new System.EventHandler(this.pictureBox15_Click);
            // 
            // pictureBox14
            // 
            this.pictureBox14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox14.Image = global::Map.Properties.Resources._7;
            this.pictureBox14.Location = new System.Drawing.Point(54, 276);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(42, 45);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox14.TabIndex = 11;
            this.pictureBox14.TabStop = false;
            this.pictureBox14.Click += new System.EventHandler(this.pictureBox14_Click);
            // 
            // pictureBox13
            // 
            this.pictureBox13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox13.Image = global::Map.Properties.Resources._6;
            this.pictureBox13.Location = new System.Drawing.Point(88, 358);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(42, 45);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox13.TabIndex = 10;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.Click += new System.EventHandler(this.pictureBox13_Click);
            // 
            // pictureBox12
            // 
            this.pictureBox12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox12.Image = global::Map.Properties.Resources._5;
            this.pictureBox12.Location = new System.Drawing.Point(212, 402);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(42, 45);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox12.TabIndex = 9;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Click += new System.EventHandler(this.pictureBox12_Click);
            // 
            // pictureBox10
            // 
            this.pictureBox10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox10.Image = global::Map.Properties.Resources._3;
            this.pictureBox10.Location = new System.Drawing.Point(268, 236);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(42, 45);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox10.TabIndex = 8;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Click += new System.EventHandler(this.pictureBox10_Click);
            // 
            // pictureBox11
            // 
            this.pictureBox11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox11.Image = global::Map.Properties.Resources._4;
            this.pictureBox11.Location = new System.Drawing.Point(363, 336);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(42, 45);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox11.TabIndex = 7;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Click += new System.EventHandler(this.pictureBox11_Click);
            // 
            // pictureBox9
            // 
            this.pictureBox9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox9.Image = global::Map.Properties.Resources._2;
            this.pictureBox9.Location = new System.Drawing.Point(277, 145);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(42, 45);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 5;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Click += new System.EventHandler(this.pictureBox9_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox3.Image = global::Map.Properties.Resources._1_png;
            this.pictureBox3.Location = new System.Drawing.Point(234, 12);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(42, 51);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBoxOfToilet
            // 
            this.pictureBoxOfToilet.Image = global::Map.Properties.Resources.map_icon_toilets;
            this.pictureBoxOfToilet.Location = new System.Drawing.Point(33, 357);
            this.pictureBoxOfToilet.Name = "pictureBoxOfToilet";
            this.pictureBoxOfToilet.Size = new System.Drawing.Size(65, 65);
            this.pictureBoxOfToilet.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxOfToilet.TabIndex = 6;
            this.pictureBoxOfToilet.TabStop = false;
            this.pictureBoxOfToilet.Click += new System.EventHandler(this.pictureBox8_Click);
            // 
            // pictureBoxOfMedical
            // 
            this.pictureBoxOfMedical.Image = global::Map.Properties.Resources.map_icon_medical;
            this.pictureBoxOfMedical.Location = new System.Drawing.Point(33, 286);
            this.pictureBoxOfMedical.Name = "pictureBoxOfMedical";
            this.pictureBoxOfMedical.Size = new System.Drawing.Size(65, 65);
            this.pictureBoxOfMedical.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxOfMedical.TabIndex = 5;
            this.pictureBoxOfMedical.TabStop = false;
            // 
            // pictureBoxOfInformation
            // 
            this.pictureBoxOfInformation.Image = global::Map.Properties.Resources.map_icon_information;
            this.pictureBoxOfInformation.Location = new System.Drawing.Point(33, 215);
            this.pictureBoxOfInformation.Name = "pictureBoxOfInformation";
            this.pictureBoxOfInformation.Size = new System.Drawing.Size(65, 65);
            this.pictureBoxOfInformation.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxOfInformation.TabIndex = 4;
            this.pictureBoxOfInformation.TabStop = false;
            this.pictureBoxOfInformation.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // pictureBoxOfEnergy
            // 
            this.pictureBoxOfEnergy.Image = global::Map.Properties.Resources.map_icon_energy_bars;
            this.pictureBoxOfEnergy.Location = new System.Drawing.Point(33, 144);
            this.pictureBoxOfEnergy.Name = "pictureBoxOfEnergy";
            this.pictureBoxOfEnergy.Size = new System.Drawing.Size(65, 65);
            this.pictureBoxOfEnergy.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxOfEnergy.TabIndex = 3;
            this.pictureBoxOfEnergy.TabStop = false;
            this.pictureBoxOfEnergy.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // pictureBoxOfDrink
            // 
            this.pictureBoxOfDrink.Image = global::Map.Properties.Resources.map_icon_drinks;
            this.pictureBoxOfDrink.Location = new System.Drawing.Point(33, 73);
            this.pictureBoxOfDrink.Name = "pictureBoxOfDrink";
            this.pictureBoxOfDrink.Size = new System.Drawing.Size(65, 65);
            this.pictureBoxOfDrink.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxOfDrink.TabIndex = 2;
            this.pictureBoxOfDrink.TabStop = false;
            this.pictureBoxOfDrink.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = global::Map.Properties.Resources.finish;
            this.pictureBox1.Location = new System.Drawing.Point(125, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(24, 71);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Map.Properties.Resources.map1;
            this.pictureBox2.Location = new System.Drawing.Point(1, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(411, 447);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox17
            // 
            this.pictureBox17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox17.Image = global::Map.Properties.Resources.map_icon_start1;
            this.pictureBox17.Location = new System.Drawing.Point(254, 401);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(56, 46);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox17.TabIndex = 14;
            this.pictureBox17.TabStop = false;
            this.pictureBox17.Click += new System.EventHandler(this.pictureBox17_Click);
            // 
            // pictureBox18
            // 
            this.pictureBox18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox18.Image = global::Map.Properties.Resources.map_icon_start1;
            this.pictureBox18.Location = new System.Drawing.Point(40, 187);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(56, 46);
            this.pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox18.TabIndex = 15;
            this.pictureBox18.TabStop = false;
            this.pictureBox18.Click += new System.EventHandler(this.pictureBox18_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox18);
            this.Controls.Add(this.pictureBox17);
            this.Controls.Add(this.pictureBox16);
            this.Controls.Add(this.pictureBox15);
            this.Controls.Add(this.pictureBox14);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Интерактивная карта";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOfToilet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOfMedical)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOfInformation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOfEnergy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOfDrink)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labeltop;
        private System.Windows.Forms.Label labelofdrink;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBoxOfDrink;
        private System.Windows.Forms.PictureBox pictureBoxOfEnergy;
        private System.Windows.Forms.PictureBox pictureBoxOfInformation;
        private System.Windows.Forms.PictureBox pictureBoxOfMedical;
        private System.Windows.Forms.PictureBox pictureBoxOfToilet;
        private System.Windows.Forms.Label labeloftoilet;
        private System.Windows.Forms.Label labelofmedicine;
        private System.Windows.Forms.Label labelofinf;
        private System.Windows.Forms.Label labelofenergy;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox18;
    }
}

